package com.example.totolist

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TotolistApplicationTests {

	@Test
	fun contextLoads() {
	}

}
