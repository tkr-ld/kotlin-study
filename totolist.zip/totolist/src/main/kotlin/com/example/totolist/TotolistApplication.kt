package com.example.totolist

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TotolistApplication

fun main(args: Array<String>) {
	runApplication<TotolistApplication>(*args)
}
