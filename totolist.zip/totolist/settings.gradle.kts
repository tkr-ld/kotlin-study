rootProject.name = "totolist"
